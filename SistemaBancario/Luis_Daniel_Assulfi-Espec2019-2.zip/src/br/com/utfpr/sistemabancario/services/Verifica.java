package br.com.utfpr.sistemabancario.services;

/**
 * Interface que define validações
 * 
 * @author Luis Daniel Assulfi
 */
public interface Verifica {

	void validar();
}
