package br.com.uftpr.service;

public interface Calc {

	int calcular();
}
